// User login
const loginForm = document.querySelector('form[action="/login"]');

loginForm.addEventListener('submit', (event) => {
  event.preventDefault();

  const email = loginForm.elements['email'].value;
  const password = loginForm.elements['password'].value;

  // Authenticate user credentials against the database
  authenticateUser(email, password).then((result) => {
    if (result === true) {
      // Redirect user to home page
      window.location.href = '/home';
    } else {
      // Display error message
      const errorElement = document.createElement('p');
      errorElement.textContent = 'Invalid email or password.';
      loginForm.appendChild(errorElement);
    }
  });
});

// User signup
const signupForm = document.querySelector('form[action="/signup"]');

signupForm.addEventListener('submit', (event) => {
  event.preventDefault();

  const name = signupForm.elements['name'].value;
  const email = signupForm.elements['email'].value;
  const password = signupForm.elements['password'].value;
  const profilePic = signupForm.elements['profile-pic'].files[0];

  // Create new user account in the database
  createUser(name, email, password, profilePic).then(() => {
    // Redirect user to home page
    window.location.href = '/home';
  });
});

// CRUD operations for posts
const postForm = document.querySelector('form[action="/posts"]');

postForm.addEventListener('submit', (event) => {
  event.preventDefault();

  const title = postForm.elements['title'].value;
  const content = postForm.elements['content'].value;

  // Create new post in the database
  createPost(title, content).then((postId) => {
    // Append new post to user's feed
    const postElement = createPostElement(title, content, postId);
    const feedElement = document.querySelector('.feed');
    feedElement.appendChild(postElement);

    // Reset form fields
    postForm.reset();
  });
});

document.addEventListener('click', (event) => {
  if (event.target.matches('.delete-post')) {
    const postId = event.target.dataset.postId;

    // Delete post from the database
    deletePost(postId).then(() => {
      // Remove post from user's feed
      const postElement = document.querySelector(`[data-post-id="${postId}"]`);
      postElement.remove();
    });
  }

  if (event.target.matches('.edit-post')) {
    const postId = event.target.dataset.postId;
    const postElement = document.querySelector(`[data-post-id="${postId}"]`);

    // Toggle edit mode
    if (postElement.contentEditable === 'false') {
      postElement.contentEditable = 'true';
      postElement.querySelector('.edit-post').textContent = 'Save';
    } else {
      const title = postElement.querySelector('.post-title').textContent;
      const content = postElement.querySelector('.post-content').textContent;

      // Update post in the database
      updatePost(postId, title, content).then(() => {
        // Toggle edit mode
        postElement.contentEditable = 'false';
        postElement.querySelector('.edit-post').textContent = 'Edit';
      });
    }
  }
});

// Functions for interacting with the database
function authenticateUser(email, password) {
  // TODO: Implement authentication logic
}

function createUser(name, email, password, profilePic) {
  // TODO: Implement user creation logic
}

function createPost(title, content) {
  // TODO: Implement post creation logic
}

function updatePost(postId, title, content) {
  // TODO: Implement
